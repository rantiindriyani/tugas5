import { writeToFile } from "latihannpm/write";

writeToFile("export.log", "Belajar Export");