import { writeToFile } from "./write.js";

writeToFile("hello.log", "ranti indriyani");

console.info("hello word")