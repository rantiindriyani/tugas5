import { writeToFile } from "latihannpm/write";

writeToFile("projec.log", "semangatlah belajar sampai mendapatkan ilmu yang bermanfaat dunia dan akhirat ");