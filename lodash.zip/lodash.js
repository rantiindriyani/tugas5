import _ from "lodash";

const name = "ranti indriyani"
const result = _.capitalize(name);

console.info(result)
