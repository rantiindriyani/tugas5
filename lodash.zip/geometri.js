// geometri.js
export function hitungLuasLingkaran(radius) {
    return Math.PI * Math.pow(radius, 2);
  }
  
  export function hitungLuasPersegi(side) {
    return Math.pow(side, 2);
  }